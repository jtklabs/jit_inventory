#!/usr/bin/env python3
"""Fetch Juniper EOL milestone tables for MX, EX, and SRX and write JSON.

Self-contained: downloads each product EOL page, extracts the milestone
tables embedded in the page HTML, and writes one JSON per series plus a
combined file into the same directory as this script.

Usage:  python3 fetch_juniper_eol.py
"""
import re, json, os, datetime, subprocess, urllib.request
from html.parser import HTMLParser

SERIES = {
    # series : (page slug, output filename)  -- MX is published on the combined M/MX page
    "MX":  ("m_series",   "mx_eol.json"),
    "EX":  ("ex_series",  "ex_eol.json"),
    "SRX": ("srx_series", "srx_eol.json"),
}
BASE = "https://support.juniper.net/support/eol/product/{slug}/"
OUTDIR = os.path.dirname(os.path.abspath(__file__))
UA = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36"


class Cell:
    def __init__(self): self.text = ""; self.links = []


class TableParser(HTMLParser):
    def __init__(self):
        super().__init__()
        self.tables = []; self.cur = None; self.in_cell = False
        self.cell = None; self.is_header_row = False; self.cur_href = None; self.row = None

    def handle_starttag(self, tag, attrs):
        a = dict(attrs)
        if tag == "table":
            self.cur = {"headers": [], "rows": []}
        elif tag == "tr" and self.cur is not None:
            self.row = []; self.is_header_row = False
        elif tag in ("td", "th") and self.cur is not None:
            self.in_cell = True; self.cell = Cell()
            if tag == "th":
                self.is_header_row = True
        elif tag == "a" and self.in_cell:
            self.cur_href = a.get("href")

    def handle_endtag(self, tag):
        if tag == "table" and self.cur is not None:
            self.tables.append(self.cur); self.cur = None
        elif tag == "tr" and self.row is not None:
            if self.is_header_row and not self.cur["headers"]:
                self.cur["headers"] = [c.text.strip() for c in self.row]
            else:
                self.cur["rows"].append(self.row)
            self.row = None
        elif tag in ("td", "th") and self.in_cell:
            self.in_cell = False
            if self.row is not None:
                self.row.append(self.cell)
            self.cell = None
        elif tag == "a" and self.in_cell:
            self.cur_href = None

    def handle_data(self, data):
        if self.in_cell and self.cell is not None:
            t = data.strip()
            if t:
                self.cell.text = (self.cell.text + " " + t).strip()
                if self.cur_href:
                    self.cell.links.append({"text": t, "href": self.cur_href})


def fetch(slug):
    """Fetch a page. Prefer curl (uses the system CA store); fall back to urllib."""
    url = BASE.format(slug=slug)
    try:
        out = subprocess.run(
            ["curl", "-sSL", "--fail", "-A", UA, url],
            capture_output=True, timeout=60,
        )
        if out.returncode == 0 and out.stdout:
            return url, out.stdout.decode("utf-8", "replace")
    except (FileNotFoundError, subprocess.SubprocessError):
        pass
    req = urllib.request.Request(url, headers={"User-Agent": UA})
    with urllib.request.urlopen(req, timeout=60) as r:
        return url, r.read().decode("utf-8", "replace")


def parse_tables(html):
    tables = []
    for span in re.findall(r"<table.*?</table>", html, re.S):
        p = TableParser(); p.feed(span)
        tables.extend(p.tables)
    return tables


def table_to_records(t):
    headers = t["headers"]; recs = []
    for row in t["rows"]:
        rec = {}; links = []
        for i, h in enumerate(headers):
            cell = row[i] if i < len(row) else None
            rec[h] = cell.text if cell else ""
            if cell:
                links.extend(cell.links)
        if links:
            rec["_links"] = links
        recs.append(rec)
    return recs


def name_table(headers):
    h0 = headers[0].lower() if headers else ""
    return "tsb_announcements" if ("bulletin" in h0 or "tsb" in h0) else "hardware_milestones"


def main():
    retrieved = datetime.date.today().isoformat()
    combined = {}
    for series, (slug, outname) in SERIES.items():
        url, html = fetch(slug)
        doc = {"series": series, "source_url": url, "retrieved": retrieved, "tables": []}
        for t in parse_tables(html):
            doc["tables"].append({
                "name": name_table(t["headers"]),
                "columns": t["headers"],
                "row_count": len(t["rows"]),
                "rows": table_to_records(t),
            })
        with open(os.path.join(OUTDIR, outname), "w", encoding="utf-8") as f:
            json.dump(doc, f, indent=2, ensure_ascii=False)
        desc = ", ".join("{0}({1})".format(x["name"], x["row_count"]) for x in doc["tables"])
        print("{0}: {1}  tables= {2}".format(series, outname, desc))
        combined[series] = doc
    with open(os.path.join(OUTDIR, "juniper_eol_all.json"), "w", encoding="utf-8") as f:
        json.dump(combined, f, indent=2, ensure_ascii=False)
    print("combined: juniper_eol_all.json")


if __name__ == "__main__":
    main()

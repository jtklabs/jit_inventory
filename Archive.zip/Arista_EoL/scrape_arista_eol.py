#!/usr/bin/env python3
"""Scrape Arista End-of-Sale notices and emit JSON.

The Arista site sometimes returns a JavaScript client challenge to simple HTTP
clients. This script can fetch directly, through Jina Reader, or auto-fallback
to Reader when the direct response is not usable. It intentionally uses only
the Python standard library for easy distribution.
"""

from __future__ import annotations

import argparse
import concurrent.futures
import datetime as dt
import html
import json
import re
import ssl
import sys
import time
from dataclasses import dataclass
from email.utils import parsedate_to_datetime
from typing import Iterable
from urllib.error import HTTPError, URLError
from urllib.parse import quote, urljoin, urlparse
from urllib.request import Request, urlopen


DEFAULT_URL = "https://www.arista.com/en/support/advisories-notices/endofsale"
READER_BASE = "https://r.jina.ai/http://"
USER_AGENT = (
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
    "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36"
)
MAX_RETRIES = 5
DATE_RE = re.compile(
    r"\b(?:\d{1,2}\s+)?"
    r"(?:Jan(?:uary)?|Feb(?:ruary)?|Mar(?:ch)?|Apr(?:il)?|May|Jun(?:e)?|"
    r"Jul(?:y)?|Aug(?:ust)?|Sep(?:t(?:ember)?)?|Oct(?:ober)?|Nov(?:ember)?|"
    r"Dec(?:ember)?)"
    r"\s+\d{1,2}(?:st|nd|rd|th)?[,]?\s+\d{4}\b"
    r"|"
    r"\b\d{1,2}\s+"
    r"(?:Jan(?:uary)?|Feb(?:ruary)?|Mar(?:ch)?|Apr(?:il)?|May|Jun(?:e)?|"
    r"Jul(?:y)?|Aug(?:ust)?|Sep(?:t(?:ember)?)?|Oct(?:ober)?|Nov(?:ember)?|"
    r"Dec(?:ember)?)"
    r"\s+\d{4}\b",
    re.IGNORECASE,
)


@dataclass(frozen=True)
class FetchResult:
    url: str
    text: str
    fetcher: str


def log(message: str, verbose: bool) -> None:
    if verbose:
        print(message, file=sys.stderr, flush=True)


def reader_url(url: str) -> str:
    # Jina Reader accepts the original URL after the /http:// prefix, including
    # an https:// source URL.
    return READER_BASE + quote(url, safe=":/?&=%#-._~")


def http_get(
    url: str,
    timeout: int,
    user_agent: str = USER_AGENT,
    verify_tls: bool = True,
) -> str:
    request = Request(
        url,
        headers={
            "User-Agent": user_agent,
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            "Accept-Language": "en-US,en;q=0.9",
        },
    )
    context = None if verify_tls else ssl._create_unverified_context()
    last_error: Exception | None = None
    for attempt in range(MAX_RETRIES + 1):
        try:
            try:
                with urlopen(request, timeout=timeout, context=context) as response:
                    raw = response.read()
                    charset = response.headers.get_content_charset() or "utf-8"
                    return raw.decode(charset, errors="replace")
            except URLError as exc:
                reason = getattr(exc, "reason", None)
                if verify_tls and isinstance(reason, ssl.SSLCertVerificationError):
                    with urlopen(
                        request,
                        timeout=timeout,
                        context=ssl._create_unverified_context(),
                    ) as response:
                        raw = response.read()
                        charset = response.headers.get_content_charset() or "utf-8"
                        return raw.decode(charset, errors="replace")
                raise
        except HTTPError as exc:
            last_error = exc
            retryable = exc.code == 429 or 500 <= exc.code < 600
            if not retryable or attempt >= MAX_RETRIES:
                raise
            retry_after = exc.headers.get("Retry-After")
            exc.close()
            if retry_after and retry_after.isdigit():
                sleep_for = float(retry_after)
            else:
                sleep_for = min(2 ** attempt, 30)
            time.sleep(sleep_for)
        except (URLError, TimeoutError, OSError) as exc:
            last_error = exc
            if attempt >= MAX_RETRIES:
                raise
            time.sleep(min(2 ** attempt, 30))
    if last_error:
        raise last_error
    raise RuntimeError(f"failed to fetch {url}")


def looks_like_challenge(text: str) -> bool:
    markers = (
        "<title>Client Challenge</title>",
        "A required part of this site couldn",
        "/_fs-ch-",
        "Please enable JavaScript to proceed",
    )
    return any(marker in text for marker in markers)


def fetch_url(url: str, fetcher: str, timeout: int) -> FetchResult:
    if fetcher == "reader":
        return FetchResult(url=url, text=http_get(reader_url(url), timeout), fetcher="reader")
    if fetcher == "direct":
        return FetchResult(url=url, text=http_get(url, timeout), fetcher="direct")

    try:
        text = http_get(url, timeout)
        if not looks_like_challenge(text) and "/end-of-sale/" in text:
            return FetchResult(url=url, text=text, fetcher="direct")
    except (HTTPError, URLError, TimeoutError, OSError):
        pass
    return FetchResult(url=url, text=http_get(reader_url(url), timeout), fetcher="reader")


def clean_text(value: str) -> str:
    value = html.unescape(value)
    value = re.sub(r"\[(.*?)\]\([^)]+\)", r"\1", value)
    value = re.sub(r"\*\*|__|`", "", value)
    value = re.sub(r"<[^>]+>", " ", value)
    value = value.replace("\xa0", " ")
    value = re.sub(r"\s+", " ", value)
    return value.strip(" \t\r\n|")


def slugify(value: str) -> str:
    value = clean_text(value).lower()
    value = value.replace("24x7", "24x7")
    value = re.sub(r"[^a-z0-9]+", "_", value)
    return value.strip("_")


def parse_date(value: str) -> str | None:
    value = clean_text(value)
    if not value:
        return None
    value = re.sub(r"(\d{1,2})(st|nd|rd|th)\b", r"\1", value, flags=re.IGNORECASE)
    value = value.replace(",", "")
    formats = (
        "%d %B %Y",
        "%d %b %Y",
        "%B %d %Y",
        "%b %d %Y",
    )
    for fmt in formats:
        try:
            return dt.datetime.strptime(value, fmt).date().isoformat()
        except ValueError:
            continue
    return None


def first_date(text: str) -> tuple[str | None, str | None]:
    match = DATE_RE.search(text)
    if not match:
        return None, None
    raw = clean_text(match.group(0))
    return raw, parse_date(raw)


def parse_published_time(text: str) -> str | None:
    match = re.search(r"^Published Time:\s*(.+)$", text, flags=re.MULTILINE)
    if not match:
        return None
    raw = match.group(1).strip()
    try:
        return parsedate_to_datetime(raw).isoformat()
    except (TypeError, ValueError):
        return raw


def parse_listing_items(markdown: str) -> list[dict]:
    pattern = re.compile(
        r"^##\s+\[(?P<title>[^\]]+)\]\((?P<url>https?://www\.arista\.com/en/support/advisories-notices/end-of-sale/[^)\s]+)[^)]*\)"
        r"\s*\n+"
        r"(?P<date>[A-Za-z]+\s+\d{1,2},\s+\d{4})"
        r"\s*\n+"
        r"(?P<summary>.*?)(?=\n\[Read More\]\((?P=url)\)|\n##\s+\[|\n\*\s+\[First\]|\Z)",
        flags=re.MULTILINE | re.DOTALL,
    )
    items: list[dict] = []
    for match in pattern.finditer(markdown):
        summary = clean_text(match.group("summary"))
        last_day_raw, last_day_iso = None, None
        last_day_match = re.search(
            r"last day to order[^.]*?(?:is|was|planned for|effective)?[^.]*?(" + DATE_RE.pattern + r")",
            summary,
            flags=re.IGNORECASE,
        )
        if last_day_match:
            last_day_raw = clean_text(last_day_match.group(1))
            last_day_iso = parse_date(last_day_raw)
        items.append(
            {
                "title": clean_text(match.group("title")),
                "url": match.group("url"),
                "listing_date": clean_text(match.group("date")),
                "listing_date_iso": parse_date(match.group("date")),
                "summary": summary,
                "listing_last_day_to_order": last_day_raw,
                "listing_last_day_to_order_iso": last_day_iso,
            }
        )
    return items


def parse_pagination_starts(markdown: str) -> list[int]:
    starts = {0}
    for match in re.finditer(r"endofsale\?start=(\d+)", markdown):
        starts.add(int(match.group(1)))
    if starts:
        max_start = max(starts)
        starts.update(range(0, max_start + 1, 10))
    return sorted(starts)


def parse_markdown_tables(markdown: str) -> list[dict]:
    tables: list[dict] = []
    lines = markdown.splitlines()
    index = 0
    while index < len(lines):
        line = lines[index].strip()
        if not line.startswith("|") or "|" not in line[1:]:
            index += 1
            continue
        block = []
        while index < len(lines) and lines[index].strip().startswith("|"):
            block.append(lines[index].strip())
            index += 1
        if len(block) < 2:
            continue
        rows = []
        for row in block:
            cells = [clean_text(cell) for cell in row.strip("|").split("|")]
            rows.append(cells)
        separator = all(re.fullmatch(r":?-{3,}:?", cell.replace(" ", "")) for cell in rows[1])
        if not separator:
            continue
        headers = rows[0]
        data_rows = rows[2:]
        tables.append({"headers": headers, "rows": data_rows})
    return tables


def rows_to_dicts(headers: list[str], rows: Iterable[list[str]]) -> list[dict]:
    records = []
    for row in rows:
        padded = row + [""] * max(0, len(headers) - len(row))
        records.append({slugify(header) or f"column_{i + 1}": padded[i] for i, header in enumerate(headers)})
    return records


def parse_milestones(markdown: str) -> tuple[list[dict], dict[str, str]]:
    milestones: list[dict] = []
    date_map: dict[str, str] = {}
    for table in parse_markdown_tables(markdown):
        headers = [slugify(header) for header in table["headers"]]
        if "milestone" not in headers or "date" not in headers:
            continue
        milestone_index = headers.index("milestone")
        date_index = headers.index("date")
        for row in table["rows"]:
            if len(row) <= max(milestone_index, date_index):
                continue
            label = clean_text(row[milestone_index])
            date_raw = clean_text(row[date_index])
            key = slugify(label)
            date_iso = parse_date(date_raw)
            record = {"key": key, "label": label, "date": date_raw, "date_iso": date_iso}
            milestones.append(record)
            if key and date_raw:
                date_map[key] = date_iso or date_raw
    return milestones, date_map


def parse_affected_products(markdown: str) -> list[dict]:
    for table in parse_markdown_tables(markdown):
        headers = [slugify(header) for header in table["headers"]]
        if any(header.startswith("affected_product") for header in headers):
            return rows_to_dicts(table["headers"], table["rows"])
    return []


def parse_detail_content(markdown: str) -> tuple[str | None, str | None, str]:
    pattern = re.compile(
        r"^##\s+(?P<title>End of Sale[^\n]*?)(?:\s+\[PDF\]\([^)]+\))?\s*\n+"
        r"(?:\*\*(?P<date>[^*]+)\*\*\s*\n+)?"
        r"(?P<body>.*?)(?=\nGet In Touch Today|\n!\[Image|\nBy clicking|\Z)",
        flags=re.MULTILINE | re.DOTALL,
    )
    matches = list(pattern.finditer(markdown))
    if not matches:
        return None, None, markdown
    match = matches[-1]
    return clean_text(match.group("title")), clean_text(match.group("date") or ""), match.group("body")


def fallback_dates(markdown: str) -> list[dict]:
    results: list[dict] = []
    seen = set()
    for line in markdown.splitlines():
        cleaned = clean_text(line)
        if not cleaned or not re.search(r"last day|end[- ]of[- ]life|end[- ]of[- ]sale", cleaned, re.IGNORECASE):
            continue
        for date_match in DATE_RE.finditer(cleaned):
            raw = clean_text(date_match.group(0))
            key = (cleaned, raw)
            if key in seen:
                continue
            seen.add(key)
            results.append(
                {
                    "context": cleaned,
                    "date": raw,
                    "date_iso": parse_date(raw),
                }
            )
    return results


def parse_detail(markdown: str, listing: dict) -> dict:
    detail_title, detail_date, body = parse_detail_content(markdown)
    milestones, dates = parse_milestones(body)
    fallback = [] if milestones else fallback_dates(body)
    if not milestones and listing.get("listing_last_day_to_order"):
        fallback.append(
            {
                "context": "Listing summary: last day to order",
                "date": listing["listing_last_day_to_order"],
                "date_iso": listing.get("listing_last_day_to_order_iso"),
            }
        )
    return {
        **listing,
        "detail_title": detail_title or listing["title"],
        "announcement_date": detail_date or listing["listing_date"],
        "announcement_date_iso": parse_date(detail_date or listing["listing_date"]),
        "published_time": parse_published_time(markdown),
        "affected_products": parse_affected_products(body),
        "milestones": milestones,
        "dates": dates,
        "fallback_dates": fallback,
    }


def discover_notices(
    base_url: str,
    fetcher: str,
    timeout: int,
    max_workers: int,
    verbose: bool,
) -> tuple[list[dict], list[dict]]:
    first = fetch_url(base_url, fetcher, timeout)
    starts = parse_pagination_starts(first.text)
    page_urls = [base_url if start == 0 else f"{base_url}?start={start}" for start in starts]
    log(f"Discovered {len(page_urls)} listing pages: starts={starts}", verbose)

    page_results: list[FetchResult] = [first]
    errors: list[dict] = []
    remaining = page_urls[1:]
    with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = {executor.submit(fetch_url, url, fetcher, timeout): url for url in remaining}
        for future in concurrent.futures.as_completed(futures):
            url = futures[future]
            try:
                result = future.result()
                page_results.append(result)
                log(f"Fetched listing page {url} via {result.fetcher}", verbose)
            except Exception as exc:  # noqa: BLE001 - keep going and report in metadata.
                errors.append({"url": url, "error": str(exc)})
                log(f"Failed listing page {url}: {exc}", verbose)

    seen = set()
    notices: list[dict] = []
    for page in sorted(page_results, key=lambda result: result.url):
        for notice in parse_listing_items(page.text):
            if notice["url"] in seen:
                continue
            seen.add(notice["url"])
            notice["listing_page_url"] = page.url
            notice["listing_fetcher"] = page.fetcher
            notices.append(notice)
    notices.sort(key=lambda item: (item.get("listing_date_iso") or "", item["title"]), reverse=True)
    return notices, errors


def enrich_notices(
    notices: list[dict],
    fetcher: str,
    timeout: int,
    max_workers: int,
    delay: float,
    verbose: bool,
) -> tuple[list[dict], list[dict]]:
    enriched: list[dict] = []
    errors: list[dict] = []

    def fetch_and_parse(index_and_notice: tuple[int, dict]) -> tuple[int, dict]:
        index, notice = index_and_notice
        if delay:
            time.sleep(delay * (index % max(1, max_workers)))
        result = fetch_url(notice["url"], fetcher, timeout)
        item = parse_detail(result.text, notice)
        item["detail_fetcher"] = result.fetcher
        return index, item

    with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = {executor.submit(fetch_and_parse, pair): pair[1] for pair in enumerate(notices)}
        for future in concurrent.futures.as_completed(futures):
            notice = futures[future]
            try:
                index, item = future.result()
                enriched.append((index, item))
                log(f"Fetched detail {index + 1}/{len(notices)}: {notice['title']}", verbose)
            except Exception as exc:  # noqa: BLE001
                errors.append({"url": notice["url"], "title": notice["title"], "error": str(exc)})
                log(f"Failed detail {notice['url']}: {exc}", verbose)

    enriched.sort(key=lambda pair: pair[0])
    return [item for _, item in enriched], errors


def scrape(args: argparse.Namespace) -> dict:
    notices, listing_errors = discover_notices(
        args.url,
        args.fetcher,
        args.timeout,
        args.max_workers,
        args.verbose,
    )
    if args.limit:
        notices = notices[: args.limit]
    log(f"Discovered {len(notices)} notices", args.verbose)
    items, detail_errors = enrich_notices(
        notices,
        args.fetcher,
        args.timeout,
        args.max_workers,
        args.delay,
        args.verbose,
    )
    return {
        "source_url": args.url,
        "scraped_at": dt.datetime.now(dt.timezone.utc).isoformat(),
        "notice_count": len(items),
        "error_count": len(listing_errors) + len(detail_errors),
        "errors": listing_errors + detail_errors,
        "items": items,
    }


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--url", default=DEFAULT_URL, help="Arista end-of-sale listing URL")
    parser.add_argument(
        "--fetcher",
        choices=("auto", "direct", "reader"),
        default="auto",
        help="HTTP fetch strategy. auto tries Arista directly then falls back to Jina Reader.",
    )
    parser.add_argument("-o", "--output", help="Write JSON to this file instead of stdout")
    parser.add_argument("--indent", type=int, default=2, help="JSON indentation; use 0 for compact JSON")
    parser.add_argument("--timeout", type=int, default=45, help="HTTP timeout in seconds")
    parser.add_argument("--max-workers", type=int, default=2, help="Concurrent detail/listing requests")
    parser.add_argument("--delay", type=float, default=0.0, help="Per-worker stagger delay in seconds")
    parser.add_argument("--limit", type=int, help="Limit notices for testing")
    parser.add_argument("-v", "--verbose", action="store_true", help="Print progress to stderr")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    data = scrape(args)
    indent = None if args.indent == 0 else args.indent
    payload = json.dumps(data, indent=indent, ensure_ascii=False)
    if args.output:
        with open(args.output, "w", encoding="utf-8") as handle:
            handle.write(payload)
            handle.write("\n")
    else:
        print(payload)
    return 0 if data["error_count"] == 0 else 1


if __name__ == "__main__":
    raise SystemExit(main())

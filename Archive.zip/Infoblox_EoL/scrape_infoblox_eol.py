#!/usr/bin/env python3
"""Collect Infoblox hardware End-of-Life data to JSON.

IMPORTANT — Infoblox is unlike the other vendors in this folder set: it does NOT
publish a public, structured per-model hardware EoL matrix.

  * The official policy page (infoblox.com/policies) publishes only the EoL
    *policy* and milestone-term glossary (parsed live by this script).
  * Authoritative per-model dates live in login-gated "End of Life Announcement"
    (EOLA) documents on support.infoblox.com (e.g. KB 8170, KB 10809).
  * Public third-party aggregators are largely "Date Not Published".

This script therefore captures what is publicly verifiable: the live policy
glossary, the well-corroborated Trinzic X5 generation EoL, and the legacy models
publicly listed as past Last Order Date. Per-model EoS/EoTS dates that are not
public are intentionally left null with a pointer to the authoritative source,
rather than guessed.

Usage:  python3 scrape_infoblox_eol.py
"""
import re, os, json, datetime, subprocess

POLICY_URL = "https://www.infoblox.com/policies/"
OUTDIR = os.path.dirname(os.path.abspath(__file__))
UA = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 Chrome/124.0 Safari/537.36"

# --- Corroborated public EoL facts (sources recorded inline) ------------------
EOL_EVENTS = [
    {
        "name": "Trinzic X5 appliance generation",
        "scope": ("All X5-generation SKUs — any Infoblox appliance (physical or "
                  "virtual) or perpetual license whose model ends in '5'. Representative "
                  "physical models: TE-805, TE-825, TE-1415, TE-1425, TE-2215, TE-2225, "
                  "TE-4015, TE-4025, TE-5005 (list is representative, not exhaustive)."),
        "last_order_date": "2024-04-30",
        "end_of_support": "2026-04-30",
        "end_of_extended_support": "2028-04-30",
        "software_eol": None,
        "replacement": "Trinzic X6 generation (e.g. TE-1506 / TE-1516), NIOS 9.0.1+",
        "confidence": "corroborated across multiple public sources",
        "sources": [
            "https://www.infoblox.com/policies/",
            "https://community.infoblox.com/t5/nios-dns-dhcp-ipam/hardware-end-of-life/td-p/23289",
            "https://vizst.com/vendors-vizst-technology-infoblox-x5-to-x6-upgrade/",
        ],
    },
]

# Models publicly listed as past Last Order Date in Infoblox NIOS 8.5 docs.
# Exact EoS/EoTS dates are not public -> left null, see authoritative source.
PAST_LOD = {
    "note": ("Listed as past Last Order Date in Infoblox NIOS 8.5 documentation. "
             "Exact End of Support / End of Technical Support dates are not published "
             "publicly — retrieve the per-model EOLA from support.infoblox.com."),
    "source": "https://infoblox-docs.refined.site/space/nios85/35479116/vNIOS+Appliances",
    "models": ["PT-1400", "PT-2200", "PT-4000", "PT-4000-10GE", "TE-100",
               "TE-810", "TE-820", "TE-1410", "TE-1420", "TE-2210", "TE-2220"],
    "eola_kb_articles": {
        "TE-100 and IB-4000": "support.infoblox.com KB 8170",
        "PT-4000": "support.infoblox.com KB 10809",
    },
}

GLOSSARY_FALLBACK = [
    {"abbr": "EOL", "term": "End of Life",
     "definition": "The date when Infoblox will cease Limited Support for a software version and all maintenance and engineering for a hardware platform or software product ceases."},
    {"abbr": "LOD", "term": "Last Order Date",
     "definition": "The last day that a product will be available for order from Infoblox and shall be removed from Infoblox's price list."},
    {"abbr": "EOLA", "term": "End of Life Announcement",
     "definition": "Issuance of an EOLA marks the beginning of the EOL life cycle for a hardware or software product. The EOLA typically precedes the LOD by 60 days."},
    {"abbr": "EOSD", "term": "End of Software Development",
     "definition": "The date when Infoblox will cease engineering support for a Major or Minor software version release."},
    {"abbr": "EOTS", "term": "End of Technical Support",
     "definition": "The date when Infoblox will cease technical support for a hardware platform or software product."},
]


def fetch(url):
    out = subprocess.run(["curl", "-sSL", "--fail", "--max-time", "45", "-A", UA, url],
                         capture_output=True)
    return out.stdout.decode("utf-8", "replace") if out.returncode == 0 else ""


def parse_glossary(html):
    if not html:
        return GLOSSARY_FALLBACK, None
    t = re.sub(r"<script.*?</script>", " ", html, flags=re.S)
    t = re.sub(r"<style.*?</style>", " ", t, flags=re.S)
    t = re.sub(r"<[^>]+>", " ", t)
    t = re.sub(r"\s+", " ", t).replace("&amp;", "&").replace("’", "'")
    eff = re.search(r"Effective as of ([A-Z][a-z]+ \d{1,2}, \d{4})", t)
    # split on "(ABBR):" markers, keep order
    markers = list(re.finditer(r"([A-Z][A-Za-z /]{3,40}?)\s*\(([A-Z]{2,5})\):", t))
    out = []
    for i, m in enumerate(markers):
        term, abbr = m.group(1).strip(), m.group(2)
        end = markers[i + 1].start() if i + 1 < len(markers) else m.end() + 400
        dfn = t[m.end():end].strip().rstrip(". ")
        if abbr in ("EOL", "LOD", "EOLA", "EOSD", "EOTS") and len(dfn) > 20:
            out.append({"abbr": abbr, "term": term, "definition": dfn[:300] + ("." if dfn else "")})
    # de-dup by abbr, keep first
    seen, dedup = set(), []
    for g in out:
        if g["abbr"] not in seen:
            seen.add(g["abbr"]); dedup.append(g)
    return (dedup or GLOSSARY_FALLBACK), (eff.group(1) if eff else None)


def main():
    retrieved = datetime.date.today().isoformat()
    glossary, effective = parse_glossary(fetch(POLICY_URL))
    doc = {
        "vendor": "Infoblox",
        "product_class": "NIOS hardware appliances (Trinzic / TE / IB / PT)",
        "retrieved": retrieved,
        "coverage": "PARTIAL — public sources only",
        "note": ("Infoblox does not publish a public per-model hardware EoL matrix. This file "
                 "captures publicly verifiable facts only. Authoritative per-model EoL dates are "
                 "in login-gated EOLA documents on support.infoblox.com."),
        "official_sources": {
            "policy_and_glossary": POLICY_URL,
            "support_portal_login_required": "https://support.infoblox.com/",
        },
        "policy_effective_date": effective,
        "milestone_glossary": glossary,
        "eol_events": EOL_EVENTS,
        "models_past_last_order_date": PAST_LOD,
    }
    with open(os.path.join(OUTDIR, "infoblox_hardware_eol.json"), "w", encoding="utf-8") as f:
        json.dump(doc, f, indent=2, ensure_ascii=False)
    print("infoblox_hardware_eol.json written")
    print("  glossary terms:", ", ".join(g["abbr"] for g in glossary),
          "| effective:", effective)
    print("  eol_events:", len(EOL_EVENTS), "| past-LOD models:", len(PAST_LOD["models"]))


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
"""Collect F5 BIG-IP hardware End-of-Life / lifecycle milestone data to JSON.

F5's authoritative source is KB article K4309 ("F5 hardware product lifecycle
support policy"), but it is served only through F5's Salesforce JS portal
(my.f5.com) with no open API or PDF and no usable archive capture. This script
therefore sources the same matrix from WorldTech IT's published mirror of K4309
(an F5 partner that tracks the official dates) and normalizes it to JSON.

  >>> Provenance: third-party mirror of F5 K4309. Verify the newest platforms
      (rSeries / VELOS) against F5 K4309 directly, as those dates change.

Milestones captured per product: First Customer Ship, End of Sale (EoS),
End of New Software Support (EoNSS), End of Software Support (EoSS),
Start of Extended Support, End of Technical Support (EoTS), End of RMA (EoRMA).

Usage:  python3 scrape_f5_eol.py
"""
import re, os, json, datetime, subprocess
from html.parser import HTMLParser

SOURCE_URL = "https://wtit.com/f5-networks-end-of-life-hardware-rma-technical-software-support/"
F5_OFFICIAL = {"K4309": "https://my.f5.com/manage/s/article/K4309",
               "K11478": "https://my.f5.com/manage/s/article/K11478"}
OUTDIR = os.path.dirname(os.path.abspath(__file__))
UA = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 Chrome/124.0 Safari/537.36"

# models the user runs (substring match, case-insensitive)
OWNED = ["4200", "i2600", "5050", "4600", "4800", "5800"]

COL_MAP = {
    "Hardware Products": "product",
    "First Customer Ship Month": "first_customer_ship",
    "End of Sale (EoS)": "end_of_sale",
    "End of New Software Support (EoNSS)": "end_of_new_software_support",
    "Hardware Product End of Software Support (EoSS)": "end_of_software_support",
    "Start of Extended Support": "start_of_extended_support",
    "Hardware Product End of Technical Support (EoTS)": "end_of_technical_support",
    "End of RMA (EoRMA)": "end_of_rma",
}
MONTHS = {m: i for i, m in enumerate(
    ["jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"], 1)}


def norm_header(h):
    return re.sub(r"\d+$", "", re.sub(r"\s+", " ", h).strip()).strip()


def to_iso(s):
    if not s:
        return None
    s = s.strip()
    if s in ("—", "-", "", "N/A", "NA", "TBD", "TBA"):
        return None
    m = re.match(r"(\d{1,2})-([A-Za-z]{3})-(\d{4})$", s)
    if m:
        mon = MONTHS.get(m.group(2).lower())
        if mon:
            return "%04d-%02d-%02d" % (int(m.group(3)), mon, int(m.group(1)))
    m = re.match(r"([A-Za-z]{3})-(\d{4})$", s)        # Mon-YYYY (ship month)
    if m:
        mon = MONTHS.get(m.group(1).lower())
        if mon:
            return "%04d-%02d" % (int(m.group(2)), mon)
    return None


def clean(s):
    s = re.sub(r"\s+", " ", s).strip()
    return None if s in ("", "—", "-", "N/A") else s


class TableParser(HTMLParser):
    def __init__(self):
        super().__init__()
        self.tables = []; self.cur = None; self.row = None; self.cell = None; self.incell = False
    def handle_starttag(self, t, a):
        if t == "table":
            self.cur = []
        elif t == "tr" and self.cur is not None:
            self.row = []
        elif t in ("td", "th") and self.row is not None:
            self.incell = True; self.cell = ""
    def handle_endtag(self, t):
        if t == "table" and self.cur is not None:
            self.tables.append(self.cur); self.cur = None
        elif t == "tr" and self.row is not None:
            self.cur.append(self.row); self.row = None
        elif t in ("td", "th") and self.incell:
            self.row.append(re.sub(r"\s+", " ", self.cell).strip()); self.incell = False
    def handle_data(self, d):
        if self.incell:
            self.cell += d


def family_of(name, fcs_iso):
    n = name
    if re.search(r"VIPRION", n, re.I): return "VIPRION"
    if re.search(r"VELOS", n, re.I) or re.match(r"[CB]X\d", n): return "VELOS"
    if re.search(r"BIG-IQ", n, re.I): return "BIG-IQ"
    if re.match(r"i\d{3,5}[a-z]?\b", n): return "iSeries"
    if re.match(r"r\d{3,5}[a-z]?\b", n): return "rSeries"
    if re.match(r"SSE\b", n): return "SSE"
    if re.match(r"\d{3,5}[a-z]?\b", n):           # appliance, optional trailing letter (4200v, 5050s)
        yr = int(fcs_iso[:4]) if fcs_iso else None
        return "legacy appliance" if (yr and yr < 2011) else "BIG-IP appliance"
    return "other"


def fetch(url):
    out = subprocess.run(["curl", "-sSL", "--fail", "--max-time", "60", "-A", UA, url],
                         capture_output=True)
    if out.returncode != 0:
        raise SystemExit("fetch failed: " + url)
    return out.stdout.decode("utf-8", "replace")


def main():
    retrieved = datetime.date.today().isoformat()
    html = fetch(SOURCE_URL)
    p = TableParser(); p.feed(html)

    glossary = []
    products = []
    for tbl in p.tables:
        rows = [r for r in tbl if any(c.strip() for c in r)]
        if not rows:
            continue
        hdr = [norm_header(c) for c in rows[0]]
        # milestone tables: header starts with "Hardware Products"
        if hdr and hdr[0] == "Hardware Products":
            keys = [COL_MAP.get(h) for h in hdr]
            for r in rows[1:]:
                cells = r + [""] * (len(hdr) - len(r))
                name = clean(cells[0])
                # skip section sub-headers (single populated cell, no dates)
                if not name or sum(1 for c in cells[1:] if c.strip()) == 0:
                    continue
                rec = {}
                for k, v in zip(keys, cells):
                    if k and k != "product":
                        rec[k] = clean(v)
                        rec[k + "_iso"] = to_iso(v)
                fcs_iso = rec.get("first_customer_ship_iso")
                products.append({"product": name,
                                 "family": family_of(name, fcs_iso),
                                 **rec})
        elif hdr[:1] == ["Term"]:
            for r in rows[1:]:
                if len(r) >= 2 and r[0].strip():
                    glossary.append({"term": clean(r[0]), "definition": clean(r[1]),
                                     "product_category": clean(r[2]) if len(r) > 2 else None})

    # group by family
    by_family = {}
    for pr in products:
        by_family.setdefault(pr["family"], []).append(pr)

    meta = {
        "vendor": "F5",
        "product_class": "BIG-IP hardware platforms",
        "retrieved": retrieved,
        "source": "WorldTech IT mirror of F5 KB K4309 (third-party; verify newest platforms against F5)",
        "source_url": SOURCE_URL,
        "f5_official_articles": F5_OFFICIAL,
        "milestone_fields": list(COL_MAP.values())[1:],
        "product_count": len(products),
    }
    full = {**meta, "milestone_glossary": glossary, "families": by_family}
    with open(os.path.join(OUTDIR, "f5_hardware_eol.json"), "w", encoding="utf-8") as f:
        json.dump(full, f, indent=2, ensure_ascii=False)
    print("f5_hardware_eol.json: %d products across %d families" % (len(products), len(by_family)))
    for fam, items in sorted(by_family.items()):
        print("   %-18s %d" % (fam, len(items)))

    # owned-fleet subset
    owned = []
    for pr in products:
        low = pr["product"].lower()
        hits = [m for m in OWNED if m.lower() in low]
        if hits:
            owned.append({**pr, "_matched": hits})
    owned_doc = {**meta, "owned_query": OWNED, "match_count": len(owned), "products": owned}
    with open(os.path.join(OUTDIR, "f5_owned_models_eol.json"), "w", encoding="utf-8") as f:
        json.dump(owned_doc, f, indent=2, ensure_ascii=False)
    print("f5_owned_models_eol.json: %d matched products" % len(owned))


if __name__ == "__main__":
    main()

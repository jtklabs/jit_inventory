#!/usr/bin/env python3
"""Collect HPE Aruba Networking Campus AP End-of-Sale / End-of-Support-Life data
for the 200, 300, and 500 series and write JSON.

Source: official Aruba EOS notice PDFs (asp-documents.arubanetworks.com). The
public EoL listing (networkingsupport.hpe.com) is behind an auth-gated GraphQL
API, so the authoritative per-series notice PDFs are used instead.

- 200 / 300 groups: each notice PDF is downloaded, text-extracted (pdftotext
  -layout), and parsed for milestone dates + affected products + recommended
  replacements.
- 500 group: no EoL/EoS notice exists (Wi-Fi 6 APs still actively supported);
  a placeholder record documents that.

Requires: pdftotext (poppler).  Usage:  python3 scrape_aruba_eol.py
"""
import re, os, json, datetime, subprocess, tempfile

BASE = "https://asp-documents.arubanetworks.com/portals/0/el/"
OUTDIR = os.path.dirname(os.path.abspath(__file__))
UA = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 Chrome/124.0 Safari/537.36"

# notice PDFs grouped by series family
NOTICES = {
    "200": [
        "EOS_Notice_200_Series_Campus_APs.pdf",
        "EOS_Notice_210_Series_Campus_APs.pdf",
        "EOS_Notice_220_Series_Campus_APs.pdf",
        "EOS_Notice-AP-220.pdf",
        "EOS_Notice-AP-270.pdf",
    ],
    "300": [
        "EOS_Notice_300_Series_Campus_APs.pdf",
        "EOS_Notice_303P_Campus_APs.pdf",
        "EOS_Notice_310_Series_Campus_APs.pdf",
        "EOS_Notice_320_Series_Campus_APs.pdf",
        "EOS_Notice_330_Series_Campus_APs.pdf",
        "EOS_Notice_340_Series_Campus_APs.pdf",
        "EOS_Notice_AP-325-F1-Campus-AP.pdf",
    ],
}

MONTHS = {m: i for i, m in enumerate(
    ["jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"], 1)}
DATE_RE = re.compile(r"([A-Za-z]{3,9})\.?\s+(\d{1,2})(?:st|nd|rd|th)?\s*,?\s*(\d{4})")
SKU_RE = re.compile(r"\b(?=[A-Z0-9]{6}\b)(?=[A-Z0-9]*[0-9])[A-Z][A-Z0-9]{5}\b")
MODEL_RE = re.compile(r"\bI?AP-\d{3}[A-Z]?\b")
SKIP_LINE = re.compile(
    r"Confidentiality level|Page \d+ of|Product Announcement|End-of-Sale of HPE|"
    r"EOSL\) Announcement|^\s*SKU\b", re.I)
BREAK_LINE = re.compile(
    r"Milestone|following terms|Definition|currently expect|"
    r"no longer orderable|no longer available", re.I)


def to_iso(s):
    if not s:
        return None
    m = DATE_RE.search(s)
    if not m:
        return None
    mon = MONTHS.get(m.group(1)[:3].lower())
    return "%04d-%02d-%02d" % (int(m.group(3)), mon, int(m.group(2))) if mon else None


def fetch_pdf(name, dest):
    url = BASE + name
    out = subprocess.run(["curl", "-sSL", "--fail", "-A", UA, url, "-o", dest],
                         capture_output=True)
    return out.returncode == 0 and os.path.getsize(dest) > 0


def pdftext(path):
    return subprocess.run(["pdftotext", "-layout", path, "-"],
                          capture_output=True).stdout.decode("utf-8", "replace")


def date_after(t, labels):
    for pat in labels:
        m = re.search(pat + r"[^\n:]*:?\s*(" + DATE_RE.pattern + ")", t, re.I)
        if m:
            return m.group(1).strip()
    return None


def collect_col(lines):
    """Group flowing single-column lines into cells that each start with a SKU."""
    entries, cur = [], None
    for ln in lines:
        if not ln.strip():
            continue
        m = SKU_RE.search(ln)
        if m and ln[:m.start()].strip() == "":
            if cur:
                entries.append(cur)
            cur = {"sku": m.group(0), "description": ln[m.end():].strip()}
        elif cur is not None:
            cur["description"] = (cur["description"] + " " + ln.strip()).strip()
    if cur:
        entries.append(cur)
    for e in entries:
        e["description"] = re.sub(r"\s+", " ", e["description"]).strip(" -")
    return entries


def parse_table(t):
    lines = t.split("\n")
    split = None
    for ln in lines:
        if "Recommended" in ln:
            split = ln.find("Recommended")
            break
    start = None
    for i, ln in enumerate(lines):
        m = SKU_RE.match(ln.strip())
        if m and ("Aruba" in ln or MODEL_RE.search(ln)):
            start = i
            break
    if start is None:
        return [], []
    single = split is None
    left, right = [], []
    for ln in lines[start:]:
        if BREAK_LINE.search(ln):
            break
        if SKIP_LINE.search(ln):
            continue
        if single:
            left.append(ln)
        else:
            left.append(ln[:split])
            right.append(ln[split:])
    return collect_col(left), collect_col(right)


def models_from(entries):
    ms = set()
    for e in entries:
        ms |= set(MODEL_RE.findall(e["description"] + " " + e["sku"]))
    return ms


def title_from(t, fname):
    m = re.search(r"(Aruba [^\n]+?(?:Campus )?(?:APs?|Access Points?))(?:\s{2,}|\n)", t)
    if m:
        return re.sub(r"\s+", " ", m.group(1)).strip()
    # fallback from filename, e.g. EOS_Notice-AP-270 -> Aruba AP-270 Campus APs
    base = fname.replace("EOS_Notice", "").replace(".pdf", "").strip("_-")
    base = base.replace("_", " ").replace("Campus APs", "").strip()
    return ("Aruba %s Campus APs" % base).replace("  ", " ").strip()


def parse_notice(fname, path):
    t = pdftext(path)
    nid = re.search(r"\bEOS-AP-\d+\b", t)
    title = title_from(t, fname)
    lo = re.search(r"final orders through\s+(" + DATE_RE.pattern + ")", t, re.I)
    ann = date_after(t, [r"announcement date", r"End-of-Sales Announcement"])
    eos = date_after(t, [r"End of Sale \(EOS\) date", r"End-of-Sales Date"])
    eosl = date_after(t, [r"End of Support Life \(EOSL\) date", r"End-of-Support Date"])
    aff, rep = parse_table(t)
    amodels = models_from(aff)
    if not amodels:
        amodels = set(MODEL_RE.findall(title))
    # keep only models in this notice's own series family (drops replacement
    # models that bleed in from single-column notices, e.g. AP-270 -> AP-37x)
    pm = re.search(r"\b(\d)(\d)\d\b", title)
    if pm:
        pref = pm.group(1) + pm.group(2)
        kept = {m for m in amodels if re.search(r"-(\d\d)\d", m).group(1) == pref}
        if kept:
            amodels = kept
    return {
        "notice_id": nid.group(0) if nid else None,
        "title": title,
        "source_pdf": BASE + fname,
        "announcement_date": ann, "announcement_date_iso": to_iso(ann),
        "last_order_date": lo.group(1).strip() if lo else None,
        "last_order_date_iso": to_iso(lo.group(1)) if lo else None,
        "end_of_sale_date": eos, "end_of_sale_date_iso": to_iso(eos),
        "end_of_support_life_date": eosl, "end_of_support_life_date_iso": to_iso(eosl),
        "affected_models": sorted(amodels),
        "replacement_models": sorted(models_from(rep)),
        "affected_products": aff,
        "recommended_replacements": rep,
    }


def main():
    retrieved = datetime.date.today().isoformat()
    combined = {"vendor": "HPE Aruba Networking", "retrieved": retrieved, "series": {}}
    tmp = tempfile.mkdtemp(prefix="aruba_eol_")
    for group, files in NOTICES.items():
        doc = {"vendor": "HPE Aruba Networking", "series_group": group,
               "product": "Campus Access Points", "retrieved": retrieved,
               "source": "Official Aruba EOS notice PDFs (asp-documents.arubanetworks.com)",
               "notice_count": 0, "notices": []}
        for fname in files:
            dest = os.path.join(tmp, fname)
            if not fetch_pdf(fname, dest):
                print("  WARN could not fetch", fname)
                continue
            doc["notices"].append(parse_notice(fname, dest))
        doc["notice_count"] = len(doc["notices"])
        outname = "aruba_%s_eol.json" % group
        with open(os.path.join(OUTDIR, outname), "w", encoding="utf-8") as f:
            json.dump(doc, f, indent=2, ensure_ascii=False)
        combined["series"][group] = doc
        print("%s: %d notices -> %s" % (group, doc["notice_count"], outname))

    # 500 series: no EoL announced (still active)
    five = {
        "vendor": "HPE Aruba Networking", "series_group": "500",
        "product": "Campus Access Points", "retrieved": retrieved,
        "status": "active - no EoL announced",
        "note": ("As of the retrieval date the Aruba/HPE 500 Series Campus APs "
                 "(Wi-Fi 6: AP-503/504/505/514/515/518/534/535/555) have no published "
                 "End-of-Sale or End-of-Support-Life notice and remain actively sold and "
                 "supported. They appear only as recommended replacements in the 200/300 "
                 "series notices."),
        "source_eol_portal": "https://networkingsupport.hpe.com/end-of-life",
        "notice_count": 0, "notices": [],
    }
    with open(os.path.join(OUTDIR, "aruba_500_eol.json"), "w", encoding="utf-8") as f:
        json.dump(five, f, indent=2, ensure_ascii=False)
    combined["series"]["500"] = five
    print("500: 0 notices (active, no EoL) -> aruba_500_eol.json")

    with open(os.path.join(OUTDIR, "aruba_all_eol.json"), "w", encoding="utf-8") as f:
        json.dump(combined, f, indent=2, ensure_ascii=False)
    print("combined -> aruba_all_eol.json")


if __name__ == "__main__":
    main()
